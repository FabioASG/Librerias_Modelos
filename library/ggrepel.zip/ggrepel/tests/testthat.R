library(testthat)
library(ggrepel)

test_check("ggrepel")
