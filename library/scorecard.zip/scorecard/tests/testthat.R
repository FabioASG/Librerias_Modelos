library(testthat)
library(scorecard)

test_check("scorecard")
