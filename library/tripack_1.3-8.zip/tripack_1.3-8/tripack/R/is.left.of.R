is.left.of <- function(x0,y0,x1,y1,x2,y2){
   # is point (x0,y0) left of the directed line 
   # (x1,y1)-->(x2,y2) ?
   left(x0,y0,x1,y1,x2,y2)
}

