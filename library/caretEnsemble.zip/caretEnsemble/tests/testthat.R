library(testthat)
library(caretEnsemble)

test_check("caretEnsemble")
