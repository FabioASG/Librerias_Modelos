
CCRUNCHER TESTS
===============

This directory contains some xml input file samples for ccruncher.
You can run any file tipying next commands on a console:

  > cd $CCRUNCHER$
  > bin/ccruncher-cmd -w --output=data/ samples/testXX.xml

The ouput will be written in files located at data directory

The CCruncher Team
http://www.ccruncher.net

