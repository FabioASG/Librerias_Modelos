.First.lib <- function(lib, pkg) library.dynam("mlbench", pkg, lib)
