.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Welcome! Related Books: `Practical Guide To Cluster Analysis in R` at https://goo.gl/13EFCZ")
}